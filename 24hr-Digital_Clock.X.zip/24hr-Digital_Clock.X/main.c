
#include <xc.h>

#define SWITCH1					0x0E
#define SWITCH2					0x0D
#define SWITCH3					0x0B
#define SWITCH4					0x07

#define HIGH				1
#define LOW                 0
#define MAX_SSD_CNT			4

#define SSD_DATA_PORT			PORTD
#define SSD_CNT_PORT			PORTA

#define ZERO				0xE7
#define ONE                 0x21
#define TWO                 0xCB
#define THREE				0x6B
#define FOUR				0x2D
#define FIVE				0x6E
#define SIX                 0xEE
#define SEVEN				0x23
#define EIGHT				0xEF
#define NINE				0x6F
#define BLANK				0x00

#define ALL_RELEASED        0x0F
#define KEY_PORT            PORTC

#define LEVEL               0
#define STATE_CHANGE        1
#define INPUT_CONFIG        0x0F

unsigned int dot;
static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
unsigned int sec=0,min_flag=0,hr_flag=0;
int min=0,hr=0;
unsigned int mode_flag=0;
unsigned char key;


void display_ssd(unsigned char data[])
{
	unsigned long int wait;
	unsigned char digit;

	for (digit = 0; digit < MAX_SSD_CNT; digit++)
	{
		SSD_DATA_PORT = data[digit];
		SSD_CNT_PORT = (SSD_CNT_PORT & 0xF0) | (0x01 << digit);

		for (wait = 1000; wait--; );
	}
}

unsigned char get_keypad(unsigned int detection_type) 
{
    static unsigned char once = 1;
    if (detection_type == STATE_CHANGE) 
    {
        if (((KEY_PORT & INPUT_CONFIG) != ALL_RELEASED) && once) 
        {
            once = 0;

            return (KEY_PORT & INPUT_CONFIG);
        } 
        else if ((KEY_PORT & INPUT_CONFIG) == ALL_RELEASED) 
        {
            once = 1;
        }
    } 
    else if (detection_type == LEVEL) 
    {
        return (KEY_PORT & INPUT_CONFIG);
    }
    return ALL_RELEASED;
}

void __interrupt() isr(void)
{
	static unsigned short count;
     
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;
        
        if (count++ == 20000)
		{
			count = 0;
            hr_flag=!hr_flag;
            min_flag=!min_flag;
            sec++;
		}
        
        if(count==10000)
        {
            dot=0x10;
        }
        else if(count==20000)
        {
            dot=BLANK;
        }
        
		TMR0IF = 0;
	}
}

void init_timer0()
{
    T08BIT = 1;

	T0CS = 0;

	TMR0ON = 1;

    PSA=1;

	TMR0 = 6;

	TMR0IF = 0;

	TMR0IE = 1;
}

void init_ssd_control(void)
{
	TRISD = 0x00;

	TRISA = TRISA & 0xF0;

	SSD_CNT_PORT = SSD_CNT_PORT & 0xF0;
}

void init_digital_keypad(void)
{
	TRISC = TRISC | INPUT_CONFIG;
}

void init_config(void)
{
    PEIE = 1;
    
	ADCON1 = 0x0F;
    
    init_digital_keypad();
    
    init_ssd_control();
    
	init_timer0();

	GIE = 1;
}
void time(void)
{
    if(sec>59)
    {
        sec=0;
        min++;
    }
    if(min>59)
    {
        min=0;
        hr++;
    }
    if(hr>23)
    {
        hr=0;
    }
}

void run_mode(void)
{
    time();
    ssd[3]=digit[min%10];
    ssd[2]=digit[min/10];
    ssd[1]=digit[hr%10]|dot;
    ssd[0]=digit[hr/10];
    display_ssd(ssd);
}


void edit_mode(void)
{    
    if(key==SWITCH3)
    {
        mode_flag=~mode_flag;   
    }
    
    if(mode_flag==0)
    {
        if(key==SWITCH1)
        {
            min++;
            if(min>59)
            {
                min=0;
            }
        }
        else if(key==SWITCH2)
        {
            min--;
            if(min<0)
            {
                min=59;
            }
        }
        
        if(min_flag)
        {
            ssd[3]=BLANK;
            ssd[2]=BLANK;
            ssd[1]=digit[hr%10];
            ssd[0]=digit[hr/10];
            display_ssd(ssd);
        }
        else if(min_flag==0)
        {
            ssd[3]=digit[min%10];
            ssd[2]=digit[min/10];
            ssd[1]=digit[hr%10];
            ssd[0]=digit[hr/10];
            display_ssd(ssd);
        }
    }
    
    if(mode_flag)
    {
        if(key==SWITCH1)
        {
            hr++;
            if(hr>23)
            {
                hr=0;
            }
        }
        else if(key==SWITCH2)
        {
            hr--;
            if(hr<0)
            {
                hr=23;
            }
        }
        if(hr_flag)
        {
            ssd[3]=digit[min%10];
            ssd[2]=digit[min/10];
            ssd[1]=BLANK;
            ssd[0]=BLANK;
            display_ssd(ssd);
        }
        else if(hr_flag==0)
        {
            ssd[3]=digit[min%10];
            ssd[2]=digit[min/10];
            ssd[1]=digit[hr%10];
            ssd[0]=digit[hr/10];
            display_ssd(ssd);
        }
       
    }
}
unsigned int fun_flag=1;
void main(void)
{
    init_config();
    while(1)
    {
        time();
        
        key = get_keypad(STATE_CHANGE);

        if (key == SWITCH4) 
        {
            fun_flag= !fun_flag;
        }
        
        if(fun_flag)
        {
            edit_mode();
        }
        else if(fun_flag==0)
        {   
            run_mode();
        }
        display_ssd(ssd);

    }
}